﻿using System;
using System.IO;
using System.Xml.Serialization;
using System.Security.Cryptography;
using System.Text;

namespace RSA_consol
{

    public class RsaEncryption
    {

        private static RSACryptoServiceProvider csp = new RSACryptoServiceProvider(2048); // провайдер криптосервиса
        private RSAParameters _privateKey;
        private RSAParameters _publicKey;

        public RsaEncryption() //инициализация ключей
        {
            _privateKey = csp.ExportParameters(true); //экспорт параметров
            _publicKey = csp.ExportParameters(false); 

        }

        public string GetPublicKey () // метод получения открытого ключа 
        {
            var sw = new StringWriter(); //записи строк
            var xs = new XmlSerializer(typeof (RSAParameters)); //серилизатор XML
            xs.Serialize(sw, _publicKey); // средство записи открытого ключа 
            return sw.ToString(); 
        }

        public string Encrypt (string plainText) // метод шифрования 
        {
            csp = new RSACryptoServiceProvider(); //новый провайдер
            csp.ImportParameters(_publicKey); 
            var data = Encoding.Unicode.GetBytes(plainText); // переменная запись
            var cypher = csp.Encrypt(data, false); // переменная зашифрованного текста
            return Convert.ToBase64String(cypher); // возвращение текста
        }

        public string Decrypt (string cypherText) // метод расшифровки 
        {
            var dataBytes = Convert.FromBase64String(cypherText);  // переменная данных байтов
            csp.ImportParameters(_privateKey);  // импорт точки, получаем закрытый ключ
            var plainText = csp.Decrypt(dataBytes, false); // передаем данные для расшифровки
            return Encoding.Unicode.GetString(plainText); 

        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            RsaEncryption rsa = new RsaEncryption();
            string cypher = string.Empty;

            Console.WriteLine($"Открытый ключ: {rsa.GetPublicKey()} \n");


            Console.WriteLine("Введите ваш текст для шифрования: ");
            var text = Console.ReadLine();
            if(!string.IsNullOrEmpty(text))
            {
                cypher = rsa.Encrypt(text);
                Console.WriteLine($"Зашифрованный текст: {cypher}");
            }
            Console.WriteLine("Нажмите любую клавишу для расшифровать текст: ");
            Console.ReadLine();
            var plainText = rsa.Decrypt(cypher);

            Console.WriteLine($"Расшифрованное сообщение {plainText}");
            Console.ReadLine();
        }
    }
}
