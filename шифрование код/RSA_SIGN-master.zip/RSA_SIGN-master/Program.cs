﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace ConsoleApp1
{
    class Program
    {
       
        static void Main()
        {
            string source;

            Console.WriteLine(" Введите ваше сообщение: ");
            source = Console.ReadLine().ToString();

            SHA256 sha256Hash = SHA256.Create();

            byte[] hashValue = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(source));

            //Значение для хранения значения со знаком.
            byte[] signedHashValue;

            // Генерируем пару открытый/закрытый ключ.
            RSA rsa = RSA.Create();

            //Создаем объект RSAPKCS1SignatureFormatter и передаем ему
            // Экземпляр RSA для передачи закрытого ключа.
            RSAPKCS1SignatureFormatter rsaFormatter = new RSAPKCS1SignatureFormatter(rsa);

            // Установите алгоритм хеширования SHA256.
             rsaFormatter.SetHashAlgorithm("SHA256");

            //Создаем подпись для hashValue и назначаем ее signedHashValue.

            signedHashValue = rsaFormatter.CreateSignature(hashValue);

            foreach (byte item in hashValue)
            {
                Console.Write(item + " ");
            }

            Console.WriteLine();

            foreach (byte item in signedHashValue)
            {
                Console.Write(item + " ");
            }

           // byte[] mass_byte = { 1, 2, 3, 4, 5 };

            RSAPKCS1SignatureDeformatter rsaDeformatter = new RSAPKCS1SignatureDeformatter(rsa);

            rsaDeformatter.SetHashAlgorithm("SHA256");

            // Проверка ЭЦП 
            if (rsaDeformatter.VerifySignature(hashValue, signedHashValue )) //mass_byte для проверки
            {
                Console.WriteLine("Цифровая подпись действительна");
            }
            else
            {
                Console.WriteLine("Цифровая подпись не действительна");
            }
            Console.ReadKey();
        }
    }
}
